import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 * SimpleCalendar
 * Contains Main Method
 * @author Sung Chi
 *
 */
enum MONTHS
{
	Jan, Feb, March, Apr, May, June, July, Aug, Sep, Oct, Nov, Dec;
}
enum DAYS
{
	Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday ;
}

public class SimpleCalendar {

	public static void main(String[] args) {

		GUICalendar guiCalendar = new GUICalendar();

	}

}
